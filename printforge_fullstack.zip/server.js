const express = require("express");
const Stripe = require("stripe");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Product catalog. Replace file names with your real files.
// Paid files stay in /private_files and are never served publicly.
const products = {
  "hex-planter": {
    name: "Hexagon Wall Planter",
    priceCents: 399,
    file: "hexagon-wall-planter.stl"
  },
  "fidget-cube": {
    name: "Mechanical Fidget Cube",
    priceCents: 249,
    file: "mechanical-fidget-cube.3mf"
  }
};

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/create-checkout-session", async (req, res) => {
  try {
    const product = products[req.body.productId];
    if (!product) return res.status(404).json({error: "Product not found"});

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{
        price_data: {
          currency: "usd",
          product_data: { name: product.name },
          unit_amount: product.priceCents
        },
        quantity: 1
      }],
      success_url: `${process.env.PUBLIC_URL}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.PUBLIC_URL}/?cancelled=1`,
      metadata: { productId: req.body.productId }
    });

    res.json({url: session.url});
  } catch (err) {
    console.error(err);
    res.status(500).json({error: "Could not create checkout session"});
  }
});

// Verify payment before issuing a short-lived download.
app.get("/session-product", async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.retrieve(req.query.session_id);
    if (session.payment_status !== "paid") return res.status(403).json({error:"Payment not verified"});
    res.json({productId: session.metadata.productId});
  } catch (e) { res.status(400).json({error:"Invalid session"}); }
});

app.get("/download/:productId", async (req, res) => {
  try {
    const product = products[req.params.productId];
    const sessionId = req.query.session_id;
    if (!product || !sessionId) return res.status(400).send("Invalid download request.");

    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (
      session.payment_status !== "paid" ||
      session.metadata.productId !== req.params.productId
    ) {
      return res.status(403).send("Payment not verified.");
    }

    const filePath = path.join(__dirname, "private_files", product.file);
    res.download(filePath, product.file);
  } catch (err) {
    console.error(err);
    res.status(500).send("Download unavailable.");
  }
});

app.listen(PORT, () => console.log(`PrintForge running on port ${PORT}`));
