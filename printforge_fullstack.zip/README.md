# PrintForge — Stripe + protected downloads

## 1. Install
Install Node.js, then in this folder run:

```bash
npm install
```

## 2. Add Stripe credentials
Copy `.env.example` to `.env` and put your Stripe **test** secret key in it:

```text
STRIPE_SECRET_KEY=sk_test_...
PUBLIC_URL=http://localhost:3000
```

Never put the secret key in `public/` or in browser JavaScript.

## 3. Add your paid files
Put paid STL/3MF files in `private_files/` and make their filenames match `server.js`.

Free files can go in `public/free/`.

## 4. Run
```bash
npm start
```
Then open http://localhost:3000

## 5. Stripe setup
The checkout uses Stripe Checkout. Start with Stripe test mode and test payments. Before accepting real money, the account owner should complete Stripe's verification and review Stripe's current requirements.

## Important
This starter verifies that the Stripe Checkout Session is paid before serving a paid file. For a production store, add stronger order records, download limits/expiring links, webhooks, rate limiting, and an admin product/file management system.
